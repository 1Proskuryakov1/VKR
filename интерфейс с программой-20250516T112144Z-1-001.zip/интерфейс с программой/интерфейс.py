import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import seaborn as sns
import torch
from transformers import BertTokenizer, BertForSequenceClassification
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import re
from nltk.corpus import stopwords
import nltk

# Загрузка необходимых данных NLTK
nltk.download('stopwords')
nltk.download('wordnet')

class NewsCategoryApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Анализатор новостных категорий")
        self.root.geometry("1000x700")
        
        # Система навигации
        self.view_stack = []
        self.current_view = None
        
        # Данные и модель
        self.df = None
        self.model = None
        self.tokenizer = None
        self.label_encoder = LabelEncoder()
        
        # Создание интерфейса
        self.show_main_view()

    def show_main_view(self):
        """Показать главное меню с вкладками"""
        self.clear_current_view()
        self.current_view = "main"
        
        # Основные вкладки
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Создаем вкладки
        self.analysis_tab = self.create_analysis_tab()
        self.classification_tab = self.create_classification_tab()
        self.prediction_tab = self.create_prediction_tab()
        
        self.notebook.add(self.analysis_tab, text="Анализ данных")
        self.notebook.add(self.classification_tab, text="Классификация")
        self.notebook.add(self.prediction_tab, text="Предсказание")
        
        # Кнопка выхода
        ttk.Button(self.root, text="Выход", command=self.root.destroy
                  ).pack(side=tk.BOTTOM, pady=10)

    def create_analysis_tab(self):
        """Создание вкладки анализа данных"""
        tab = ttk.Frame(self.notebook)
        
        # Загрузка данных
        load_frame = ttk.LabelFrame(tab, text="Загрузка данных")
        load_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(load_frame, text="Загрузить данные", command=self.load_data
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(load_frame, text="Назад", command=self.go_back
                  ).pack(side=tk.RIGHT, padx=5)
        
        # Визуализация
        viz_frame = ttk.LabelFrame(tab, text="Визуализация")
        viz_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        btn_frame = ttk.Frame(viz_frame)
        btn_frame.pack(fill=tk.X, pady=5)
        
        ttk.Button(btn_frame, text="Распределение", 
                  command=lambda: self.show_analysis_detail("Распределение категорий", self.plot_categories)
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Длина заголовков", 
                  command=lambda: self.show_analysis_detail("Длина заголовков", self.plot_headline_lengths)
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Длина описаний", 
                  command=lambda: self.show_analysis_detail("Длина описаний", self.plot_description_lengths)
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Тренды", 
                  command=lambda: self.show_analysis_detail("Тренды по времени", self.plot_trends)
                  ).pack(side=tk.LEFT, padx=5)
        
        self.analysis_canvas_frame = ttk.Frame(viz_frame)
        self.analysis_canvas_frame.pack(fill=tk.BOTH, expand=True)
        
        return tab

    def create_classification_tab(self):
        """Создание вкладки классификации"""
        tab = ttk.Frame(self.notebook)
        
        # Управление моделью
        model_frame = ttk.LabelFrame(tab, text="Модель")
        model_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(model_frame, text="Загрузить модель", command=self.load_model
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(model_frame, text="Обучить модель", command=self.train_model
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(model_frame, text="Оценить модель", command=self.evaluate_model
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(model_frame, text="Назад", command=self.go_back
                  ).pack(side=tk.RIGHT, padx=5)
        
        # Результаты
        self.results_frame = ttk.LabelFrame(tab, text="Результаты")
        self.results_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.results_text = tk.Text(self.results_frame, wrap=tk.WORD)
        self.results_text.pack(fill=tk.BOTH, expand=True)
        
        self.results_canvas_frame = ttk.Frame(self.results_frame)
        self.results_canvas_frame.pack(fill=tk.BOTH, expand=True)
        
        return tab

    def create_prediction_tab(self):
        """Создание вкладки предсказания"""
        tab = ttk.Frame(self.notebook)
        
        # Ввод текста
        input_frame = ttk.LabelFrame(tab, text="Ввод текста")
        input_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.text_entry = tk.Text(input_frame, height=5, wrap=tk.WORD)
        self.text_entry.pack(fill=tk.X, padx=5, pady=5)
        
        # Кнопки управления
        btn_frame = ttk.Frame(input_frame)
        btn_frame.pack(fill=tk.X)
        
        ttk.Button(btn_frame, text="Предсказать", command=self.predict_category
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="Назад", command=self.go_back
                  ).pack(side=tk.RIGHT, padx=5)
        
        # Результат
        result_frame = ttk.LabelFrame(tab, text="Результат")
        result_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.prediction_result = tk.StringVar()
        ttk.Label(result_frame, textvariable=self.prediction_result, 
                 font=('Arial', 12)).pack(pady=10)
        
        # Примеры
        examples_frame = ttk.LabelFrame(tab, text="Примеры")
        examples_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(examples_frame, text="Политика", 
                  command=lambda: self.set_example("The president announced new economic policies today.")
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(examples_frame, text="Спорт", 
                  command=lambda: self.set_example("The team won the championship with a last-minute goal.")
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(examples_frame, text="Технологии", 
                  command=lambda: self.set_example("New smartphone features AI-powered camera technology.")
                  ).pack(side=tk.LEFT, padx=5)
        ttk.Button(examples_frame, text="Назад", command=self.go_back
                  ).pack(side=tk.RIGHT, padx=5)
        
        return tab

    def show_analysis_detail(self, title, plot_func):
        """Показать детали анализа"""
        self.view_stack.append((self.current_view, self.notebook))
        self.current_view = f"analysis_{title}"
        self.clear_current_view()
        
        # Создаем контейнер
        container = ttk.Frame(self.root)
        container.pack(fill=tk.BOTH, expand=True)
        
        # Заголовок
        ttk.Label(container, text=title, font=('Arial', 14)).pack(pady=10)
        
        # Кнопка назад
        ttk.Button(container, text="Назад", command=self.go_back
                  ).pack(side=tk.TOP, anchor=tk.NE, padx=10, pady=5)
        
        # Область для графика
        canvas_frame = ttk.Frame(container)
        canvas_frame.pack(fill=tk.BOTH, expand=True)
        
        # Отображаем график
        plot_func(canvas_frame)

    def go_back(self):
        """Возврат к предыдущему виду"""
        if self.view_stack:
            prev_view, prev_widget = self.view_stack.pop()
            self.clear_current_view()
            
            if prev_view == "main":
                self.show_main_view()
            elif prev_view.startswith("analysis"):
                self.show_main_view()
        else:
            self.root.destroy()

    def clear_current_view(self):
        """Очистить текущее представление"""
        for widget in self.root.winfo_children():
            widget.destroy()

    def load_data(self):
        """Загрузка данных из файла"""
        filepath = filedialog.askopenfilename(
            title="Выберите файл с данными",
            filetypes=(("JSON files", "*.json"), ("All files", "*.*"))
        )
        if filepath:
            try:
                self.df = pd.read_json(filepath, lines=True)
                messagebox.showinfo("Успех", f"Данные успешно загружены. Записей: {len(self.df)}")
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось загрузить данные: {str(e)}")

    def plot_categories(self, frame):
        """Построение графика распределения категорий"""
        if self.df is None:
            messagebox.showerror("Ошибка", "Сначала загрузите данные")
            return
        
        self.clear_plot(frame)
        
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.countplot(y=self.df['category'], order=self.df['category'].value_counts().index, ax=ax)
        ax.set_title('Распределение категорий новостей')
        ax.set_xlabel('Количество статей')
        ax.set_ylabel('Категория')
        
        self.display_plot(fig, frame)

    def plot_headline_lengths(self, frame):
        """Построение графика длины заголовков"""
        if self.df is None:
            messagebox.showerror("Ошибка", "Сначала загрузите данные")
            return
        
        self.clear_plot(frame)
        
        headline_lengths = self.df['headline'].apply(len)
        quantiles = headline_lengths.quantile([0.25, 0.5, 0.75])
        
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.histplot(headline_lengths, bins=50, kde=True, ax=ax)
        
        for quantile in quantiles:
            ax.axvline(quantile, color='r', linestyle='--')
        
        ax.set_title('Распределение длины заголовков')
        ax.set_xlabel('Длина заголовка (кол-во символов)')
        ax.set_ylabel('Количество')
        
        self.display_plot(fig, frame)

    def plot_description_lengths(self, frame):
        """Построение графика длины описаний"""
        if self.df is None:
            messagebox.showerror("Ошибка", "Сначала загрузите данные")
            return
        
        self.clear_plot(frame)
        
        description_lengths = self.df['short_description'].apply(len)
        quantiles = description_lengths.quantile([0.25, 0.5, 0.75])
        
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.histplot(description_lengths, bins=50, kde=True, ax=ax)
        
        for quantile in quantiles:
            ax.axvline(quantile, color='r', linestyle='--')
        
        ax.set_title('Распределение длины описаний')
        ax.set_xlabel('Длина описания (кол-во символов)')
        ax.set_ylabel('Количество')
        
        self.display_plot(fig, frame)

    def plot_trends(self, frame):
        """Построение графика трендов"""
        if self.df is None:
            messagebox.showerror("Ошибка", "Сначала загрузите данные")
            return
        
        self.clear_plot(frame)
        
        self.df['date'] = pd.to_datetime(self.df['date'])
        self.df['year_month'] = self.df['date'].dt.to_period('M')
        
        fig, ax = plt.subplots(figsize=(12, 8))
        
        for category in self.df['category'].unique():
            subset = self.df[self.df['category'] == category]
            subset.groupby('year_month').size().plot(label=category, ax=ax)
        
        ax.set_title('Тренды новостей по категориям во времени', size=12)
        ax.set_xlabel('Дата')
        ax.set_ylabel('Количество новостей')
        ax.legend(loc='upper left', bbox_to_anchor=(1, 1))
        
        self.display_plot(fig, frame)

    def load_model(self):
        """Загрузка модели"""
        try:
            model_path = filedialog.askdirectory(title="Выберите папку с моделью")
            if model_path:
                self.model = BertForSequenceClassification.from_pretrained(model_path)
                self.tokenizer = BertTokenizer.from_pretrained(model_path)
                messagebox.showinfo("Успех", "Модель успешно загружена")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось загрузить модель: {str(e)}")

    def train_model(self):
        """Обучение модели"""
        messagebox.showinfo("Информация", "Обучение модели может занять много времени. Пожалуйста, используйте предварительно обученную модель.")

    def evaluate_model(self):
        """Оценка модели"""
        if self.model is None or self.tokenizer is None:
            messagebox.showerror("Ошибка", "Сначала загрузите модель")
            return
        
        if self.df is None:
            messagebox.showerror("Ошибка", "Сначала загрузите данные")
            return
        
        try:
            # Подготовка данных
            sampled_df = self.prepare_data_for_training()
            self.label_encoder.fit(sampled_df['category'])
            
            # Разделение данных
            train_texts, eval_texts, train_labels, eval_labels = train_test_split(
                sampled_df['short_description'].tolist(), 
                sampled_df['category_encoded'].tolist(),
                test_size=0.2,
                random_state=42
            )
            
            # Оценка модели
            device = "cuda" if torch.cuda.is_available() else "cpu"
            self.model.to(device)
            
            self.model.eval()
            predictions = []
            true_labels = []
            
            for i in range(0, len(eval_texts), 8):
                batch_texts = eval_texts[i:i+8]
                batch_labels = eval_labels[i:i+8]
                
                inputs = self.tokenizer(batch_texts, padding=True, truncation=True, return_tensors='pt')
                inputs = {k: v.to(device) for k, v in inputs.items()}
                labels = torch.tensor(batch_labels).to(device)
                
                with torch.no_grad():
                    outputs = self.model(**inputs)
                    _, predicted = torch.max(outputs.logits, 1)
                
                predictions.extend(predicted.cpu().numpy())
                true_labels.extend(labels.cpu().numpy())
            
            # Вывод результатов
            accuracy = accuracy_score(true_labels, predictions)
            report = classification_report(true_labels, predictions, 
                                         target_names=self.label_encoder.classes_)
            
            self.results_text.delete(1.0, tk.END)
            self.results_text.insert(tk.END, f"Accuracy: {accuracy * 100:.2f}%\n\n")
            self.results_text.insert(tk.END, "Classification Report:\n")
            self.results_text.insert(tk.END, report)
            
            # Матрица ошибок
            self.clear_plot(self.results_canvas_frame)
            
            cm = confusion_matrix(true_labels, predictions)
            fig, ax = plt.subplots(figsize=(10, 8))
            sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", 
                       xticklabels=self.label_encoder.classes_, 
                       yticklabels=self.label_encoder.classes_, ax=ax)
            ax.set_xlabel('Predicted')
            ax.set_ylabel('True')
            
            self.display_plot(fig, self.results_canvas_frame)
            
        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка при оценке модели: {str(e)}")

    def predict_category(self):
        """Предсказание категории для текста"""
        if self.model is None or self.tokenizer is None:
            messagebox.showerror("Ошибка", "Сначала загрузите модель")
            return
        
        text = self.text_entry.get("1.0", tk.END).strip()
        if not text:
            messagebox.showerror("Ошибка", "Введите текст для классификации")
            return
        
        try:
            device = "cuda" if torch.cuda.is_available() else "cpu"
            self.model.to(device)
            
            # Предобработка текста
            text = self.preprocess_text(text)
            
            # Предсказание
            inputs = self.tokenizer(text, padding=True, truncation=True, return_tensors='pt')
            inputs = {k: v.to(device) for k, v in inputs.items()}
            
            with torch.no_grad():
                outputs = self.model(**inputs)
                _, predicted = torch.max(outputs.logits, 1)
            
            predicted_category = self.label_encoder.inverse_transform(predicted.cpu().numpy())
            self.prediction_result.set(f"Предсказанная категория: {predicted_category[0]}")
            
        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка при предсказании: {str(e)}")

    def prepare_data_for_training(self):
        """Подготовка данных для обучения"""
        sampled_df = pd.DataFrame()
        categories = self.df['category'].unique()
        
        for category in categories:
            category_df = self.df[self.df['category'] == category]
            sampled_category_df = category_df.sample(n=min(500, len(category_df)), random_state=42)
            sampled_df = pd.concat([sampled_df, sampled_category_df], ignore_index=True)
        
        sampled_df = sampled_df[['short_description', 'category']]
        sampled_df['short_description'] = sampled_df['short_description'].apply(self.preprocess_text)
        sampled_df['category_encoded'] = self.label_encoder.fit_transform(sampled_df['category'])
        
        return sampled_df

    def preprocess_text(self, text):
        """Предобработка текста"""
        text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
        text = text.lower()
        text = re.sub(r"\s+", " ", text).strip()
        stop_words = set(stopwords.words('english'))
        text = ' '.join([word for word in text.split() if word not in stop_words])
        return text

    def set_example(self, text):
        """Установка примера текста"""
        self.text_entry.delete(1.0, tk.END)
        self.text_entry.insert(tk.END, text)

    def clear_plot(self, frame):
        """Очистить область с графиком"""
        for widget in frame.winfo_children():
            widget.destroy()

    def display_plot(self, figure, frame):
        """Отобразить график в указанном фрейме"""
        canvas = FigureCanvasTkAgg(figure, master=frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

class NewsCategoryDataset:
    def __init__(self, texts, labels):
        self.texts = texts
        self.labels = labels
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        return self.texts[idx], self.labels[idx]

if __name__ == "__main__":
    root = tk.Tk()
    app = NewsCategoryApp(root)
    root.mainloop()
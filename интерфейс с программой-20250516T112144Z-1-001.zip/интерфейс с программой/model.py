import pandas as pd
import re
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertForSequenceClassification
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import nltk
from tqdm import tqdm
from torch.optim import AdamW

nltk.download('stopwords')
nltk.download('wordnet')

# Класс классификатора новостей
class NewsClassifier:
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.label_encoder = LabelEncoder()
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
    
    def load_model(self, model_path):
        """Загрузка предварительно обученной модели и токенизатора"""
        self.model = BertForSequenceClassification.from_pretrained(model_path)
        self.tokenizer = BertTokenizer.from_pretrained(model_path)
        self.model.to(self.device)
    
    def preprocess_text(self, text):
        """Предварительная обработка текста"""
        text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
        text = text.lower()
        text = re.sub(r"\s+", " ", text).strip()
        stop_words = set(stopwords.words('english'))
        text = ' '.join([word for word in text.split() if word not in stop_words])
        return text
    
    def predict(self, text):
        """Предсказание категории для текста"""
        if self.model is None or self.tokenizer is None:
            raise ValueError("Модель не загружена. Сначала вызовите load_model()")
        
        processed_text = self.preprocess_text(text)
        inputs = self.tokenizer(processed_text, padding=True, truncation=True, return_tensors='pt')
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        
        with torch.no_grad():
            outputs = self.model(**inputs)
            _, predicted = torch.max(outputs.logits, 1)
        
        return self.label_encoder.inverse_transform(predicted.cpu().numpy())[0]

# Функция для подготовки данных
def prepare_data(df, sample_size=500):
    """Подготовка данных для обучения"""
    # Удаление пустых строк
    df = df[(df['headline'] != "") & (df['short_description'] != "")]
    
    # Объединение заголовка и описания
    df['text'] = df['headline'] + " " + df['short_description']
    
    # Сбалансированная выборка
    sampled_df = pd.DataFrame()
    categories = df['category'].unique()
    
    for category in categories:
        category_df = df[df['category'] == category]
        if len(category_df) < sample_size:
            sampled_category_df = category_df
        else:
            sampled_category_df = category_df.sample(n=sample_size, random_state=42)
        sampled_df = pd.concat([sampled_df, sampled_category_df], ignore_index=True)
    
    return sampled_df[['text', 'category']]

# Класс датасета
class NewsDataset(Dataset):
    def __init__(self, texts, labels):
        self.texts = texts
        self.labels = labels
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        return self.texts[idx], self.labels[idx]

# Функция для оценки модели
def evaluate_model(model, dataloader, device, label_encoder):
    model.eval()
    predictions = []
    true_labels = []
    
    with torch.no_grad():
        for texts, labels in dataloader:
            inputs = tokenizer(texts, padding=True, truncation=True, return_tensors='pt')
            inputs = {k: v.to(device) for k, v in inputs.items()}
            labels = labels.to(device)
            
            outputs = model(**inputs)
            _, preds = torch.max(outputs.logits, 1)
            
            predictions.extend(preds.cpu().numpy())
            true_labels.extend(labels.cpu().numpy())
    
    # Метрики
    accuracy = accuracy_score(true_labels, predictions)
    print(f"\nAccuracy: {accuracy:.4f}")
    
    # Матрица ошибок
    cm = confusion_matrix(true_labels, predictions)
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=label_encoder.classes_, 
                yticklabels=label_encoder.classes_)
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title('Confusion Matrix')
    plt.show()
    
    # Отчет классификации
    print("\nClassification Report:")
    print(classification_report(true_labels, predictions, 
                               target_names=label_encoder.classes_,
                               zero_division=0))

# Основной процесс обучения
def train_model(df, model_save_path, num_epochs=3):
    # Подготовка данных
    data = prepare_data(df)
    data['text'] = data['text'].apply(lambda x: re.sub(r"[^a-zA-Z0-9\s]", "", x.lower()))
    
    # Кодирование меток
    label_encoder = LabelEncoder()
    data['label'] = label_encoder.fit_transform(data['category'])
    
    # Разделение данных
    train_texts, val_texts, train_labels, val_labels = train_test_split(
        data['text'].tolist(), 
        data['label'].tolist(), 
        test_size=0.2, 
        random_state=42
    )
    
    # Создание датасетов и загрузчиков
    train_dataset = NewsDataset(train_texts, train_labels)
    val_dataset = NewsDataset(val_texts, val_labels)
    
    train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False)
    
    # Инициализация модели
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = BertForSequenceClassification.from_pretrained(
        'bert-base-uncased', 
        num_labels=len(label_encoder.classes_)
    model.to(device)
    
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    optimizer = AdamW(model.parameters(), lr=2e-5)
    
    # Обучение
    for epoch in range(num_epochs):
        model.train()
        total_loss = 0
        
        progress_bar = tqdm(train_loader, desc=f"Epoch {epoch + 1}/{num_epochs}")
        for texts, labels in progress_bar:
            inputs = tokenizer(texts, padding=True, truncation=True, return_tensors='pt')
            inputs = {k: v.to(device) for k, v in inputs.items()}
            labels = labels.to(device)
            
            optimizer.zero_grad()
            outputs = model(**inputs, labels=labels)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            progress_bar.set_postfix({'loss': total_loss / (progress_bar.n + 1)})
        
        # Оценка после эпохи
        print(f"\nEpoch {epoch + 1} Evaluation:")
        evaluate_model(model, val_loader, device, label_encoder)
    
    # Сохранение модели
    model.save_pretrained(model_save_path)
    tokenizer.save_pretrained(model_save_path)
    
    # Создание и возврат классификатора
    classifier = NewsClassifier()
    classifier.model = model
    classifier.tokenizer = tokenizer
    classifier.label_encoder = label_encoder
    
    return classifier

# Пример использования
if __name__ == "__main__":
    # Загрузка данных
    df = pd.read_json("News_Category_Dataset_v3.json", lines=True)
    
    # Обучение модели
    model_path = "news_classifier_model"
    classifier = train_model(df, model_path, num_epochs=3)
    
    # Тестирование классификатора
    test_text = "The president announced new economic policies today"
    predicted_category = classifier.predict(test_text)
    print(f"\nPredicted category for test text: {predicted_category}")
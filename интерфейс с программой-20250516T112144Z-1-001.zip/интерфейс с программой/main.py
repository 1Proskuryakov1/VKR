from интерфейс import NewsCategoryApp
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = NewsCategoryApp(root)
    root.mainloop()
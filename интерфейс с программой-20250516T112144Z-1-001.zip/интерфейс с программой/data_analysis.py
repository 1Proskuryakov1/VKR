import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
from wordcloud import STOPWORDS

class DataAnalyzer:
    def __init__(self, df):
        self.df = df
    
    def plot_categories(self):
        plt.figure(figsize=(12,8))
        sns.countplot(y=self.df['category'], order=self.df['category'].value_counts().index)
        plt.title('Распределение категорий новостей')
        plt.xlabel('Количество статей')
        plt.ylabel('Категория')
        return plt.gcf()